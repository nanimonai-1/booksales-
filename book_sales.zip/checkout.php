<?php
require_once __DIR__ . '/includes/functions.php';
require_customer();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: cart.php');
    exit;
}

$cart = $_SESSION['cart'] ?? [];
if (!$cart) {
    set_flash('error', '购物车为空，无法下单');
    header('Location: cart.php');
    exit;
}

$customer_id = (int)$_SESSION['customer_id'];
$ids = array_map('intval', array_keys($cart));
$in  = implode(',', $ids);

// 读取书价与库存
$res = $conn->query("SELECT b.book_id, b.book_name, b.retail_price, COALESCE(i.quantity,0) AS stock
                     FROM book b LEFT JOIN inventory i ON b.book_id=i.book_id
                     WHERE b.book_id IN ($in)");
$rows = $res->fetch_all(MYSQLI_ASSOC);

// 库存校验
$total = 0.0;
$lines = [];
foreach ($rows as $r) {
    $bid = (int)$r['book_id'];
    $qty = (int)$cart[$bid];
    if ($qty > (int)$r['stock']) {
        set_flash('error', '《' . $r['book_name'] . '》库存不足，当前仅 ' . (int)$r['stock'] . ' 本');
        header('Location: cart.php');
        exit;
    }
    $total += $qty * (float)$r['retail_price'];
    $lines[] = ['book_id' => $bid, 'qty' => $qty, 'price' => (float)$r['retail_price']];
}

$conn->begin_transaction();
try {
    // 2.2.3 创建订单主表（客户自助下单 admin_id=NULL，满足触发器约束）
    $stmt = $conn->prepare("INSERT INTO customer_order(customer_id, admin_id, status, total_amount, payment_time)
                            VALUES (?, NULL, '待支付', ?, NULL)");
    $stmt->bind_param('id', $customer_id, $total);
    $stmt->execute();
    $order_id = $conn->insert_id;

    // 明细 + 扣库存
    $det = $conn->prepare('INSERT INTO order_detail(order_id, book_id, quantity, price) VALUES (?,?,?,?)');
    $upd = $conn->prepare('UPDATE inventory SET quantity = quantity - ? WHERE book_id = ?');
    foreach ($lines as $ln) {
        $det->bind_param('iiid', $order_id, $ln['book_id'], $ln['qty'], $ln['price']);
        $det->execute();
        $upd->bind_param('ii', $ln['qty'], $ln['book_id']);
        $upd->execute();
        refresh_inventory_status($conn, $ln['book_id']);
    }

    $conn->commit();
    $_SESSION['cart'] = [];
    set_flash('success', '订单提交成功！订单号 #' . $order_id . '，总额 ￥' . number_format($total, 2));
    header('Location: order_detail.php?id=' . $order_id);
    exit;
} catch (Throwable $ex) {
    $conn->rollback();
    set_flash('error', '下单失败：' . $ex->getMessage());
    header('Location: cart.php');
    exit;
}
