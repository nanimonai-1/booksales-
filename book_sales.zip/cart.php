<?php
require_once __DIR__ . '/includes/functions.php';
require_customer();

$cart = $_SESSION['cart'] ?? [];
$items = [];
$total = 0.0;
if ($cart) {
    $ids = array_map('intval', array_keys($cart));
    $in  = implode(',', $ids);
    $res = $conn->query("SELECT b.book_id, b.book_name, b.author, b.retail_price,
                                COALESCE(i.quantity,0) AS stock
                         FROM book b LEFT JOIN inventory i ON b.book_id=i.book_id
                         WHERE b.book_id IN ($in)");
    while ($r = $res->fetch_assoc()) {
        $bid = (int)$r['book_id'];
        $qty = (int)$cart[$bid];
        $sub = $qty * (float)$r['retail_price'];
        $total += $sub;
        $r['qty'] = $qty;
        $r['subtotal'] = $sub;
        $items[] = $r;
    }
}

$page_title = '我的购物车';
include __DIR__ . '/includes/header.php';
?>
<div class="flex-between mb">
    <h1 class="page-title" style="margin:0">🛒 我的购物车</h1>
    <?php if ($items): ?>
    <form method="post" action="cart_action.php" onsubmit="return confirm('确定清空购物车？')">
        <input type="hidden" name="action" value="clear">
        <button class="btn btn-gray" type="submit">清空购物车</button>
    </form>
    <?php endif; ?>
</div>

<?php if (!$items): ?>
    <div class="flash flash-info">购物车是空的，<a href="index.php">去挑选图书</a></div>
<?php else: ?>
<table class="data">
    <thead><tr><th>书名</th><th>作者</th><th>单价</th><th>数量</th><th>小计</th><th>操作</th></tr></thead>
    <tbody>
    <?php foreach ($items as $it): ?>
        <tr>
            <td><?= e($it['book_name']) ?></td>
            <td><?= e($it['author']) ?></td>
            <td>￥<?= number_format($it['retail_price'], 2) ?></td>
            <td>
                <form method="post" action="cart_action.php" style="display:flex;gap:6px;align-items:center">
                    <input type="hidden" name="action" value="update">
                    <input type="hidden" name="book_id" value="<?= (int)$it['book_id'] ?>">
                    <input type="number" name="quantity" value="<?= $it['qty'] ?>" min="1" max="<?= (int)$it['stock'] ?>" style="width:70px;padding:4px">
                    <button class="btn btn-sm btn-gray" type="submit">更新</button>
                </form>
                <?php if ($it['qty'] > $it['stock']): ?><span class="muted" style="color:#c0392b">库存不足(仅<?= (int)$it['stock'] ?>)</span><?php endif; ?>
            </td>
            <td>￥<?= number_format($it['subtotal'], 2) ?></td>
            <td>
                <form method="post" action="cart_action.php">
                    <input type="hidden" name="action" value="remove">
                    <input type="hidden" name="book_id" value="<?= (int)$it['book_id'] ?>">
                    <button class="btn btn-sm btn-danger" type="submit">移除</button>
                </form>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
<div class="flex-between" style="margin-top:18px">
    <div class="muted">共 <?= count($items) ?> 种图书</div>
    <div style="font-size:18px">合计：<strong style="color:#e4483c">￥<?= number_format($total, 2) ?></strong>
        <form method="post" action="checkout.php" style="display:inline-block;margin-left:14px">
            <button class="btn btn-success" type="submit">提交订单</button>
        </form>
    </div>
</div>
<?php endif; ?>
<?php include __DIR__ . '/includes/footer.php'; ?>
