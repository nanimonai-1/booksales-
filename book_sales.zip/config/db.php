<?php
date_default_timezone_set('Asia/Shanghai');
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$DB_HOST = 'localhost';
$DB_NAME = 'book_sales';
$DB_USER = 'root';
$DB_PWD  = '123456';   // ←  MySQL 密码
$conn = new mysqli($DB_HOST, $DB_USER, $DB_PWD, $DB_NAME);
if ($conn->connect_error) {
    die('数据库连接失败：' . $conn->connect_error);
}
$conn->set_charset('utf8mb4');

/** 密码校验：兼容 MD5 密文 与 明文测试数据 */
function verify_password($input, $stored) {
    if ($stored === md5($input)) return true;
    if ($stored === $input)      return true;
    return false;
}

/** 新注册用户密码入库（MD5） */
function hash_password($input) {
    return md5($input);
}
?>
