<?php
/** 页面头部与导航 —— 用户前台 */
if (!isset($page_title)) $page_title = '网上书城';
$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($page_title) ?> - 网上书城</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<header class="topbar">
    <div class="container topbar-inner">
        <a class="logo" href="index.php">📚 网上书城</a>
        <nav class="nav">
            <a href="index.php">图书商城</a>
            <?php if (is_customer_logged_in()): ?>
                <a href="cart.php">🛒 购物车</a>
                <a href="orders.php">我的订单</a>
                <span class="nav-user">你好，<?= e($_SESSION['customer_name']) ?></span>
                <a href="logout.php">退出</a>
            <?php else: ?>
                <a href="login.php">登录</a>
                <a href="register.php">注册</a>
            <?php endif; ?>
            <a class="admin-entry" href="admin/index.php">管理后台</a>
        </nav>
    </div>
</header>
<main class="container">
<?php if ($flash): ?>
    <div class="flash flash-<?= e($flash['type']) ?>"><?= e($flash['msg']) ?></div>
<?php endif; ?>
