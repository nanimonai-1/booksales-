<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../config/db.php';   // 关键：把 db.php（含 verify_password）引进来

/** HTML 转义 */
function e($str) {
    return htmlspecialchars((string)$str, ENT_QUOTES, 'UTF-8');
}

/** 登录状态判断 */
function is_customer_logged_in() { return isset($_SESSION['customer_id']); }
function is_admin_logged_in()    { return isset($_SESSION['admin_id']); }

/** 登录拦截 */
function require_customer() {
    if (!is_customer_logged_in()) { header('Location: login.php'); exit; }
}
function require_admin() {
    if (!is_admin_logged_in()) { header('Location: login.php'); exit; }
}

/** 闪存提示 */
function set_flash($type, $msg) { $_SESSION['flash'] = ['type' => $type, 'msg' => $msg]; }
function get_flash() {
    if (!empty($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $f;
    }
    return null;
}

/** 根据库存数量刷新库存状态 */
function refresh_inventory_status($conn, $book_id) {
    $stmt = $conn->prepare('SELECT quantity, warning_threshold FROM inventory WHERE book_id=?');
    $stmt->bind_param('i', $book_id);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    if (!$row) return;
    $q = (int)$row['quantity'];
    $t = (int)$row['warning_threshold'];
    if ($q <= 0)      $status = '缺货';
    elseif ($q < $t)  $status = '预警';
    else              $status = '正常';
    $up = $conn->prepare('UPDATE inventory SET status=? WHERE book_id=?');
    $up->bind_param('si', $status, $book_id);
    $up->execute();
}
?>
