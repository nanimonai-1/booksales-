</main>
<footer class="footer">
    <div class="container">网上书城 · 基于 PHP + MySQL(book_sales) 课程示例项目</div>
</footer>
</body>
</html>
