<?php
require_once __DIR__ . '/includes/functions.php';
require_customer();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: cart.php');
    exit;
}
if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];  // [book_id => qty]

$action = $_POST['action'] ?? '';

switch ($action) {
    case 'add':               // 2.2.1 添加图书至购物车
        $bid = (int)($_POST['book_id'] ?? 0);
        if ($bid > 0) {
            $_SESSION['cart'][$bid] = ($_SESSION['cart'][$bid] ?? 0) + 1;
            set_flash('success', '已加入购物车');
        }
        header('Location: ' . ($_POST['redirect'] ?? 'index.php'));
        break;

    case 'update':            // 更新某本书数量
        $bid = (int)($_POST['book_id'] ?? 0);
        $qty = max(0, (int)($_POST['quantity'] ?? 0));
        if ($bid > 0) {
            if ($qty === 0) unset($_SESSION['cart'][$bid]);
            else $_SESSION['cart'][$bid] = $qty;
        }
        header('Location: cart.php');
        break;

    case 'remove':            // 移除单本
        $bid = (int)($_POST['book_id'] ?? 0);
        unset($_SESSION['cart'][$bid]);
        set_flash('info', '已移除');
        header('Location: cart.php');
        break;

    case 'clear':             // 2.2.2 清空购物车
        $_SESSION['cart'] = [];
        set_flash('info', '购物车已清空');
        header('Location: cart.php');
        break;

    default:
        header('Location: cart.php');
}
exit;
