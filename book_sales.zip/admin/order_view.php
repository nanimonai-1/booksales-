<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

$order_id = (int)($_GET['id'] ?? 0);
$stmt = $conn->prepare('SELECT co.*, c.customer_name, c.contact_info, c.shipping_address
                        FROM customer_order co JOIN customer c ON co.customer_id=c.customer_id
                        WHERE co.order_id=?');
$stmt->bind_param('i', $order_id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
if (!$order) { set_flash('error', '订单不存在'); header('Location: orders.php'); exit; }

$d = $conn->prepare('SELECT od.quantity, od.price, b.book_name, b.author
                     FROM order_detail od JOIN book b ON od.book_id=b.book_id WHERE od.order_id=?');
$d->bind_param('i', $order_id);
$d->execute();
$details = $d->get_result()->fetch_all(MYSQLI_ASSOC);

$page_title = '订单详情 #' . $order_id;
include __DIR__ . '/admin_header.php';
?>
<div class="flex-between mb">
    <h1 class="page-title" style="margin:0">订单详情 #<?= $order_id ?></h1>
    <a class="btn btn-gray btn-sm" href="orders.php">返回订单列表</a>
</div>
<div class="card mb">
    <p><strong>客户：</strong><?= e($order['customer_name']) ?>（<?= e($order['contact_info']) ?>）</p>
    <p><strong>收货地址：</strong><?= e($order['shipping_address']) ?></p>
    <p><strong>状态：</strong><?= e($order['status']) ?></p>
    <p><strong>下单时间：</strong><?= e($order['created_at']) ?>　<strong>支付时间：</strong><?= e($order['payment_time'] ?? '未支付') ?></p>
</div>
<table class="data">
    <thead><tr><th>书名</th><th>作者</th><th>单价</th><th>数量</th><th>小计</th></tr></thead>
    <tbody>
    <?php foreach ($details as $it): ?>
        <tr>
            <td><?= e($it['book_name']) ?></td>
            <td><?= e($it['author']) ?></td>
            <td>￥<?= number_format($it['price'], 2) ?></td>
            <td><?= (int)$it['quantity'] ?></td>
            <td>￥<?= number_format($it['price'] * $it['quantity'], 2) ?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
    <tfoot><tr><td colspan="4" class="right"><strong>订单总额</strong></td><td><strong style="color:#e4483c">￥<?= number_format($order['total_amount'], 2) ?></strong></td></tr></tfoot>
</table>
<?php include __DIR__ . '/admin_footer.php'; ?>
