<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

$book_count  = $conn->query('SELECT COUNT(*) c FROM book')->fetch_assoc()['c'];
$warn_count  = $conn->query("SELECT COUNT(*) c FROM inventory WHERE quantity < warning_threshold")->fetch_assoc()['c'];
$order_count = $conn->query('SELECT COUNT(*) c FROM customer_order')->fetch_assoc()['c'];
$pending     = $conn->query("SELECT COUNT(*) c FROM customer_order WHERE status='已支付'")->fetch_assoc()['c'];

$page_title = '控制台';
include __DIR__ . '/admin_header.php';
?>
<h1 class="page-title">控制台</h1>
<div class="stat-cards">
    <div class="stat"><div class="num"><?= (int)$book_count ?></div><div class="label">图书总数</div></div>
    <div class="stat"><div class="num" style="color:#e08e0b"><?= (int)$warn_count ?></div><div class="label">库存预警</div></div>
    <div class="stat"><div class="num"><?= (int)$order_count ?></div><div class="label">订单总数</div></div>
    <div class="stat"><div class="num" style="color:#2f9e5f"><?= (int)$pending ?></div><div class="label">待发货订单</div></div>
</div>
<div class="card">
    <h3 style="margin-bottom:10px">快捷入口</h3>
    <a class="btn btn-sm" href="books.php">图书管理</a>
    <a class="btn btn-sm btn-success" href="book_edit.php">新增图书</a>
    <a class="btn btn-sm btn-warn" href="inventory.php">查看库存预警</a>
    <a class="btn btn-sm btn-gray" href="orders.php">处理订单</a>
</div>
<?php include __DIR__ . '/admin_footer.php'; ?>
