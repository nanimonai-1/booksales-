<?php
/** 管理后台头部（含侧边栏） */
if (!isset($page_title)) $page_title = '管理后台';
$flash = get_flash();
$cur = basename($_SERVER['PHP_SELF']);
function nav_active($f, $cur) { return $f === $cur ? 'active' : ''; }
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($page_title) ?> - 管理后台</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<header class="topbar">
    <div class="container topbar-inner">
        <a class="logo" href="index.php">🛠️ 图书管理后台</a>
        <nav class="nav">
            <span class="nav-user"><?= e($_SESSION['admin_name'] ?? '') ?>（<?= e($_SESSION['role_name'] ?? '') ?>）</span>
            <a href="../index.php">前台商城</a>
            <a href="logout.php">退出</a>
        </nav>
    </div>
</header>
<div class="container" style="padding-top:24px;padding-bottom:40px">
<?php if ($flash): ?>
    <div class="flash flash-<?= e($flash['type']) ?>"><?= e($flash['msg']) ?></div>
<?php endif; ?>
<div class="admin-layout">
    <aside class="sidebar">
        <a class="<?= nav_active('index.php',$cur) ?>" href="index.php">📊 控制台</a>
        <a class="<?= nav_active('books.php',$cur) ?>" href="books.php">📚 图书管理</a>
        <a class="<?= nav_active('book_edit.php',$cur) ?>" href="book_edit.php">➕ 新增图书</a>
        <a class="<?= nav_active('inventory.php',$cur) ?>" href="inventory.php">⚠️ 库存预警</a>
        <a class="<?= nav_active('orders.php',$cur) ?>" href="orders.php">📦 订单处理</a>
    </aside>
    <div class="admin-main">
