<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

// 3.2 删除图书
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
    if ($_SESSION['role_name'] !== '超级管理员') {
        set_flash('error', '仅超级管理员可删除图书');
    } else {
        $bid = (int)($_POST['book_id'] ?? 0);
        try {
            $conn->begin_transaction();
            $conn->query("DELETE FROM inventory WHERE book_id=$bid");
            $del = $conn->prepare('DELETE FROM book WHERE book_id=?');
            $del->bind_param('i', $bid);
            $del->execute();
            $conn->commit();
            set_flash('success', '图书已删除');
        } catch (Throwable $ex) {
            $conn->rollback();
            set_flash('error', '删除失败：该图书可能已被订单/采购引用。' . $ex->getMessage());
        }
    }
    header('Location: books.php');
    exit;
}

$kw = trim($_GET['kw'] ?? '');
$sql = 'SELECT b.book_id, b.book_name, b.author, b.publisher, b.retail_price,
               COALESCE(i.quantity,0) AS quantity, COALESCE(i.status,\'缺货\') AS status
        FROM book b LEFT JOIN inventory i ON b.book_id=i.book_id';
$params = [];
if ($kw !== '') {
    $sql .= ' WHERE b.book_name LIKE ? OR b.author LIKE ? OR b.publisher LIKE ?';
    $like = "%$kw%"; $params = [$like, $like, $like];
}
$sql .= ' ORDER BY b.book_id';
$stmt = $conn->prepare($sql);
if ($params) $stmt->bind_param('sss', ...$params);
$stmt->execute();
$books = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

$page_title = '图书管理';
include __DIR__ . '/admin_header.php';
?>
<div class="flex-between mb">
    <h1 class="page-title" style="margin:0">📚 图书管理</h1>
    <a class="btn btn-success" href="book_edit.php">➕ 新增图书</a>
</div>
<form class="searchbar" method="get">
    <input type="text" name="kw" placeholder="按书名/作者/出版社搜索" value="<?= e($kw) ?>">
    <button class="btn" type="submit">搜索</button>
    <?php if ($kw !== ''): ?><a class="btn btn-gray" href="books.php">清除</a><?php endif; ?>
</form>
<table class="data">
    <thead><tr><th>ID</th><th>书名</th><th>作者</th><th>出版社</th><th>售价</th><th>库存</th><th>状态</th><th>操作</th></tr></thead>
    <tbody>
    <?php foreach ($books as $b): ?>
        <tr>
            <td><?= (int)$b['book_id'] ?></td>
            <td><?= e($b['book_name']) ?></td>
            <td><?= e($b['author']) ?></td>
            <td><?= e($b['publisher']) ?></td>
            <td>￥<?= number_format($b['retail_price'], 2) ?></td>
            <td><?= (int)$b['quantity'] ?></td>
            <td><?php $c=['正常'=>'badge-green','预警'=>'badge-orange','缺货'=>'badge-red'][$b['status']]??'badge-gray'; ?><span class="badge <?= $c ?>"><?= e($b['status']) ?></span></td>
            <td>
                <a class="btn btn-sm btn-warn" href="book_edit.php?id=<?= (int)$b['book_id'] ?>">修改</a>
                <form method="post" style="display:inline" onsubmit="return confirm('确定删除《<?= e($b['book_name']) ?>》？')">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="book_id" value="<?= (int)$b['book_id'] ?>">
                    <button class="btn btn-sm btn-danger" type="submit">删除</button>
                </form>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
<?php include __DIR__ . '/admin_footer.php'; ?>
