<?php
require_once __DIR__ . '/../includes/functions.php';

if (is_admin_logged_in()) { header('Location: index.php'); exit; }

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $account  = trim($_POST['account'] ?? '');
    $password = $_POST['password'] ?? '';
    if ($account === '' || $password === '') {
        $errors[] = '请输入账号和密码';
    } else {
        $stmt = $conn->prepare('SELECT a.admin_id, a.admin_name, a.admin_password, r.role_name
                                FROM admin a JOIN admin_role r ON a.role_id=r.role_id
                                WHERE a.admin_account=?');
        $stmt->bind_param('s', $account);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        if ($row && verify_password($password, $row['admin_password'])) {
            $_SESSION['admin_id']   = (int)$row['admin_id'];
            $_SESSION['admin_name'] = $row['admin_name'];
            $_SESSION['role_name']  = $row['role_name'];
            header('Location: index.php');
            exit;
        }
        $errors[] = '账号或密码错误';
    }
}
$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head><meta charset="utf-8"><title>管理员登录</title><link rel="stylesheet" href="../assets/css/style.css"></head>
<body>
<div class="form-box" style="margin-top:80px">
    <h2>🛠️ 管理员登录</h2>
    <?php foreach ($errors as $err): ?><div class="flash flash-error"><?= e($err) ?></div><?php endforeach; ?>
    <form method="post">
        <div class="form-row"><label>管理员账号</label><input type="text" name="account" value="<?= e($_POST['account'] ?? '') ?>"></div>
        <div class="form-row"><label>密码</label><input type="password" name="password"></div>
        <button class="btn btn-block" type="submit">登录</button>
    </form>
    <p class="muted" style="text-align:center;margin-top:12px">测试：daikai / 060215（超级管理员）</p>
    <p class="form-tip"><a href="../index.php">← 返回前台商城</a></p>
</div>
</body>
</html>
