<?php
require_once __DIR__ . '/../includes/functions.php';
unset($_SESSION['admin_id'], $_SESSION['admin_name'], $_SESSION['role_name']);
header('Location: login.php');
exit;
