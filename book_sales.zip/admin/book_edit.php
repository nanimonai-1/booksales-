<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

// 图书新增/修改：数据库触发器限定「仅超级管理员可新增图书」
$is_super = ($_SESSION['role_name'] === '超级管理员');
$book_id  = (int)($_GET['id'] ?? 0);
$is_edit  = $book_id > 0;
$errors   = [];

// 编辑时读取原数据
$book = ['book_name'=>'','author'=>'','publisher'=>'','retail_price'=>'','quantity'=>0,'warning_threshold'=>10];
if ($is_edit) {
    $stmt = $conn->prepare('SELECT b.book_name, b.author, b.publisher, b.retail_price,
                                   COALESCE(i.quantity,0) AS quantity, COALESCE(i.warning_threshold,10) AS warning_threshold
                            FROM book b LEFT JOIN inventory i ON b.book_id=i.book_id WHERE b.book_id=?');
    $stmt->bind_param('i', $book_id);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    if (!$row) { set_flash('error', '图书不存在'); header('Location: books.php'); exit; }
    $book = $row;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name   = trim($_POST['book_name'] ?? '');
    $author = trim($_POST['author'] ?? '');
    $pub    = trim($_POST['publisher'] ?? '');
    $price  = (float)($_POST['retail_price'] ?? 0);
    $qty    = max(0, (int)($_POST['quantity'] ?? 0));
    $thr    = max(0, (int)($_POST['warning_threshold'] ?? 10));

    if (!$is_super) $errors[] = '仅超级管理员可维护图书信息';
    if ($name === '')   $errors[] = '请填写书名';
    if ($author === '') $errors[] = '请填写作者';
    if ($pub === '')    $errors[] = '请填写出版社';
    if ($price < 0)     $errors[] = '售价不能为负';

    if (!$errors) {
        $admin_id = (int)$_SESSION['admin_id'];
        try {
            $conn->begin_transaction();
            if ($is_edit) {
                // 3.3 修改图书
                $up = $conn->prepare('UPDATE book SET book_name=?, author=?, publisher=?, retail_price=?, admin_id=? WHERE book_id=?');
                $up->bind_param('sssdii', $name, $author, $pub, $price, $admin_id, $book_id);
                $up->execute();
                // 同步库存
                $ex = $conn->query("SELECT book_id FROM inventory WHERE book_id=$book_id")->num_rows;
                if ($ex) {
                    $ui = $conn->prepare('UPDATE inventory SET quantity=?, warning_threshold=? WHERE book_id=?');
                    $ui->bind_param('iii', $qty, $thr, $book_id);
                    $ui->execute();
                } else {
                    $ii = $conn->prepare('INSERT INTO inventory(book_id, quantity, warning_threshold) VALUES (?,?,?)');
                    $ii->bind_param('iii', $book_id, $qty, $thr);
                    $ii->execute();
                }
                refresh_inventory_status($conn, $book_id);
                $conn->commit();
                set_flash('success', '图书修改成功');
            } else {
                // 3.1 新增图书（触发 check_admin_permission_before_insert）
                $ins = $conn->prepare('INSERT INTO book(book_name, author, publisher, retail_price, admin_id) VALUES (?,?,?,?,?)');
                $ins->bind_param('sssdi', $name, $author, $pub, $price, $admin_id);
                $ins->execute();
                $new_id = $conn->insert_id;
                $ii = $conn->prepare('INSERT INTO inventory(book_id, quantity, warning_threshold) VALUES (?,?,?)');
                $ii->bind_param('iii', $new_id, $qty, $thr);
                $ii->execute();
                refresh_inventory_status($conn, $new_id);
                $conn->commit();
                set_flash('success', '图书新增成功');
            }
            header('Location: books.php');
            exit;
        } catch (Throwable $ex) {
            $conn->rollback();
            $errors[] = '保存失败：' . $ex->getMessage();
        }
    }
    // 回填表单
    $book = ['book_name'=>$name,'author'=>$author,'publisher'=>$pub,'retail_price'=>$price,'quantity'=>$qty,'warning_threshold'=>$thr];
}

$page_title = $is_edit ? '修改图书' : '新增图书';
include __DIR__ . '/admin_header.php';
?>
<h1 class="page-title"><?= $is_edit ? '✏️ 修改图书' : '➕ 新增图书' ?></h1>
<?php if (!$is_super): ?><div class="flash flash-error">当前账号（<?= e($_SESSION['role_name']) ?>）无图书维护权限，仅超级管理员可操作。</div><?php endif; ?>
<?php foreach ($errors as $err): ?><div class="flash flash-error"><?= e($err) ?></div><?php endforeach; ?>
<div class="card" style="max-width:640px">
    <form method="post">
        <div class="form-row"><label>书名</label><input type="text" name="book_name" value="<?= e($book['book_name']) ?>"></div>
        <div class="form-row"><label>作者</label><input type="text" name="author" value="<?= e($book['author']) ?>"></div>
        <div class="form-row"><label>出版社</label><input type="text" name="publisher" value="<?= e($book['publisher']) ?>"></div>
        <div class="form-row"><label>零售价</label><input type="number" step="0.01" min="0" name="retail_price" value="<?= e($book['retail_price']) ?>"></div>
        <div class="form-row"><label>库存数量</label><input type="number" min="0" name="quantity" value="<?= (int)$book['quantity'] ?>"></div>
        <div class="form-row"><label>预警阈值</label><input type="number" min="0" name="warning_threshold" value="<?= (int)$book['warning_threshold'] ?>"></div>
        <button class="btn" type="submit" <?= $is_super ? '' : 'disabled' ?>>保存</button>
        <a class="btn btn-gray" href="books.php">返回</a>
    </form>
</div>
<?php include __DIR__ . '/admin_footer.php'; ?>
