<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

// 3.4 库存预警图书查看：quantity < warning_threshold 视为预警/缺货
$rows = $conn->query("SELECT b.book_id, b.book_name, b.author, i.quantity, i.warning_threshold, i.status
                      FROM inventory i JOIN book b ON i.book_id=b.book_id
                      WHERE i.quantity < i.warning_threshold
                      ORDER BY i.quantity ASC")->fetch_all(MYSQLI_ASSOC);

$page_title = '库存预警';
include __DIR__ . '/admin_header.php';
?>
<h1 class="page-title">⚠️ 库存预警图书</h1>
<p class="muted mb">以下图书库存已低于预警阈值，请及时补货。</p>
<?php if (!$rows): ?>
    <div class="flash flash-success">当前没有库存预警的图书 👍</div>
<?php else: ?>
<table class="data">
    <thead><tr><th>ID</th><th>书名</th><th>作者</th><th>当前库存</th><th>预警阈值</th><th>状态</th><th>操作</th></tr></thead>
    <tbody>
    <?php foreach ($rows as $r): ?>
        <tr>
            <td><?= (int)$r['book_id'] ?></td>
            <td><?= e($r['book_name']) ?></td>
            <td><?= e($r['author']) ?></td>
            <td style="color:#c0392b;font-weight:700"><?= (int)$r['quantity'] ?></td>
            <td><?= (int)$r['warning_threshold'] ?></td>
            <td><?php $c=$r['quantity']<=0?'badge-red':'badge-orange'; ?><span class="badge <?= $c ?>"><?= e($r['status']) ?></span></td>
            <td><a class="btn btn-sm btn-warn" href="book_edit.php?id=<?= (int)$r['book_id'] ?>">补货/修改</a></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
<?php endif; ?>
<?php include __DIR__ . '/admin_footer.php'; ?>
