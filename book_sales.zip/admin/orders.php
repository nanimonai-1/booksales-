<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

// 3.5.2 修改订单状态
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'update_status') {
    $oid = (int)($_POST['order_id'] ?? 0);
    $new = $_POST['status'] ?? '';
    $allowed = ['待支付','已支付','已发货','已完成','已取消'];
    if ($oid > 0 && in_array($new, $allowed, true)) {
        if ($new === '已支付') {
            $stmt = $conn->prepare("UPDATE customer_order SET status=?, payment_time=IFNULL(payment_time, NOW()) WHERE order_id=?");
        } else {
            $stmt = $conn->prepare("UPDATE customer_order SET status=? WHERE order_id=?");
        }
        $stmt->bind_param('si', $new, $oid);
        $stmt->execute();
        set_flash('success', "订单 #$oid 状态已更新为「$new」");
    } else {
        set_flash('error', '参数错误');
    }
    header('Location: orders.php' . (!empty($_POST['filter']) ? '?filter=' . urlencode($_POST['filter']) : ''));
    exit;
}

// 3.5.1 查看所有订单 / 待发货订单
$filter = $_GET['filter'] ?? 'all';
$sql = 'SELECT co.order_id, co.status, co.total_amount, co.created_at, co.payment_time,
               c.customer_name, co.admin_id
        FROM customer_order co JOIN customer c ON co.customer_id=c.customer_id';
if ($filter === 'pending') $sql .= " WHERE co.status='已支付'";   // 已支付待发货
elseif ($filter === 'unpaid') $sql .= " WHERE co.status='待支付'";
$sql .= ' ORDER BY co.created_at DESC, co.order_id DESC';
$orders = $conn->query($sql)->fetch_all(MYSQLI_ASSOC);

$statuses = ['待支付','已支付','已发货','已完成','已取消'];
$badge = ['待支付'=>'badge-orange','已支付'=>'badge-blue','已发货'=>'badge-blue','已完成'=>'badge-green','已取消'=>'badge-gray'];

$page_title = '订单处理';
include __DIR__ . '/admin_header.php';
?>
<h1 class="page-title">📦 订单处理</h1>
<div class="mb">
    <a class="btn btn-sm <?= $filter==='all'?'':'btn-gray' ?>" href="orders.php">全部订单</a>
    <a class="btn btn-sm <?= $filter==='pending'?'':'btn-gray' ?>" href="orders.php?filter=pending">待发货（已支付）</a>
    <a class="btn btn-sm <?= $filter==='unpaid'?'':'btn-gray' ?>" href="orders.php?filter=unpaid">待支付</a>
</div>
<?php if (!$orders): ?>
    <div class="flash flash-info">没有符合条件的订单</div>
<?php else: ?>
<table class="data">
    <thead><tr><th>订单号</th><th>客户</th><th>金额</th><th>当前状态</th><th>下单时间</th><th>修改状态</th><th>详情</th></tr></thead>
    <tbody>
    <?php foreach ($orders as $o): ?>
        <tr>
            <td>#<?= (int)$o['order_id'] ?></td>
            <td><?= e($o['customer_name']) ?></td>
            <td>￥<?= number_format($o['total_amount'], 2) ?></td>
            <td><span class="badge <?= $badge[$o['status']] ?? 'badge-gray' ?>"><?= e($o['status']) ?></span></td>
            <td><?= e($o['created_at']) ?></td>
            <td>
                <form method="post" style="display:flex;gap:6px">
                    <input type="hidden" name="action" value="update_status">
                    <input type="hidden" name="order_id" value="<?= (int)$o['order_id'] ?>">
                    <input type="hidden" name="filter" value="<?= e($filter) ?>">
                    <select name="status">
                        <?php foreach ($statuses as $s): ?>
                            <option value="<?= $s ?>" <?= $s===$o['status']?'selected':'' ?>><?= $s ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button class="btn btn-sm" type="submit">更新</button>
                </form>
            </td>
            <td><a class="btn btn-sm btn-gray" href="order_view.php?id=<?= (int)$o['order_id'] ?>">查看</a></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
<?php endif; ?>
<?php include __DIR__ . '/admin_footer.php'; ?>
