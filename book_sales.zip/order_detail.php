<?php
require_once __DIR__ . '/includes/functions.php';
require_customer();

$order_id    = (int)($_GET['id'] ?? 0);
$customer_id = (int)$_SESSION['customer_id'];

// 校验订单归属，防止越权查看他人订单
$stmt = $conn->prepare('SELECT co.order_id, co.status, co.total_amount, co.created_at, co.payment_time,
                               c.customer_name, c.shipping_address, c.contact_info
                        FROM customer_order co JOIN customer c ON co.customer_id=c.customer_id
                        WHERE co.order_id=? AND co.customer_id=?');
$stmt->bind_param('ii', $order_id, $customer_id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();

if (!$order) {
    set_flash('error', '订单不存在或无权查看');
    header('Location: orders.php');
    exit;
}

$d = $conn->prepare('SELECT od.quantity, od.price, b.book_name, b.author
                     FROM order_detail od JOIN book b ON od.book_id=b.book_id
                     WHERE od.order_id=?');
$d->bind_param('i', $order_id);
$d->execute();
$details = $d->get_result()->fetch_all(MYSQLI_ASSOC);

$page_title = '订单详情 #' . $order_id;
include __DIR__ . '/includes/header.php';
?>
<div class="flex-between mb">
    <h1 class="page-title" style="margin:0">订单详情 #<?= $order_id ?></h1>
    <a class="btn btn-gray btn-sm" href="orders.php">返回订单列表</a>
</div>
<div class="card mb">
    <p><strong>状态：</strong><?= e($order['status']) ?></p>
    <p><strong>收货人：</strong><?= e($order['customer_name']) ?>（<?= e($order['contact_info']) ?>）</p>
    <p><strong>收货地址：</strong><?= e($order['shipping_address']) ?></p>
    <p><strong>下单时间：</strong><?= e($order['created_at']) ?></p>
    <p><strong>支付时间：</strong><?= e($order['payment_time'] ?? '未支付') ?></p>
</div>
<table class="data">
    <thead><tr><th>书名</th><th>作者</th><th>单价</th><th>数量</th><th>小计</th></tr></thead>
    <tbody>
    <?php foreach ($details as $it): ?>
        <tr>
            <td><?= e($it['book_name']) ?></td>
            <td><?= e($it['author']) ?></td>
            <td>￥<?= number_format($it['price'], 2) ?></td>
            <td><?= (int)$it['quantity'] ?></td>
            <td>￥<?= number_format($it['price'] * $it['quantity'], 2) ?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
    <tfoot><tr><td colspan="4" class="right"><strong>订单总额</strong></td><td><strong style="color:#e4483c">￥<?= number_format($order['total_amount'], 2) ?></strong></td></tr></tfoot>
</table>
<!-- 新增支付按钮 -->
<?php if ($order['status'] == '待支付'): ?>
<div style="margin:30px 0;">
    <form action="pay_order.php" method="post">
        <input type="hidden" name="order_id" value="<?= $oid ?>">
        <button type="submit" style="background:#007aff;color:#fff;border:none;padding:10px 25px;border-radius:6px;font-size:16px;">
            立即模拟支付
        </button>
    </form>
</div>
<?php endif; ?>
<a href="orders.php"><button>返回我的订单列表</button></a>

<?php include __DIR__ . '/includes/footer.php'; ?>
