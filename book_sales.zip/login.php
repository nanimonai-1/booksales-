<?php
require_once __DIR__ . '/includes/functions.php';

// ===== 兜底：若上面的文件里缺这些函数，就地补上，保证不再报 undefined =====
if (!isset($conn)) {
    require_once __DIR__ . '/config/db.php';
}
if (!function_exists('verify_password')) {
    function verify_password($input, $stored) {
        return ($stored === md5($input) || $stored === $input); // 兼容MD5密文和明文
    }
}
if (!function_exists('e')) {
    function e($str) { return htmlspecialchars((string)$str, ENT_QUOTES, 'UTF-8'); }
}
if (!function_exists('set_flash')) {
    function set_flash($t, $m) { $_SESSION['flash'] = ['type' => $t, 'msg' => $m]; }
}
// =====================================================================

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $account  = trim($_POST['account'] ?? '');
    $password = $_POST['password'] ?? '';
    if ($account === '' || $password === '') {
        $errors[] = '请输入账号和密码';
    } else {
        $stmt = $conn->prepare('SELECT customer_id, customer_name, password FROM customer WHERE account=?');
        $stmt->bind_param('s', $account);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        if ($row && verify_password($password, $row['password'])) {
            $_SESSION['customer_id']   = (int)$row['customer_id'];
            $_SESSION['customer_name'] = $row['customer_name'];
            set_flash('success', '登录成功，欢迎回来！');
            header('Location: index.php');
            exit;
        }
        $errors[] = '账号或密码错误';
    }
}

$page_title = '用户登录';
include __DIR__ . '/includes/header.php';
?>
<div class="form-box">
    <h2>用户登录</h2>
    <?php foreach ($errors as $err): ?>
        <div class="flash flash-error"><?= e($err) ?></div>
    <?php endforeach; ?>
    <form method="post">
        <div class="form-row"><label>登录账号</label><input type="text" name="account" value="<?= e($_POST['account'] ?? '') ?>"></div>
        <div class="form-row"><label>密码</label><input type="password" name="password"></div>
        <button class="btn btn-block" type="submit">登录</button>
    </form>
    <p class="form-tip">还没有账号？<a href="register.php">立即注册</a></p>
    <p class="muted" style="text-align:center;margin-top:10px">测试账号：limx / 123456</p>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
