<?php
require_once __DIR__ . '/includes/functions.php';

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = trim($_POST['customer_name'] ?? '');
    $account  = trim($_POST['account'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm'] ?? '';
    $contact  = trim($_POST['contact_info'] ?? '');
    $address  = trim($_POST['shipping_address'] ?? '');

    if ($name === '')     $errors[] = '请填写姓名';
    if ($account === '')  $errors[] = '请填写登录账号';
    if ($contact === '')  $errors[] = '请填写联系方式';
    if ($address === '')  $errors[] = '请填写收货地址';
    if (strlen($password) < 6) $errors[] = '密码至少 6 位';
    if ($password !== $confirm) $errors[] = '两次输入的密码不一致';

    // 账号唯一性检查
    if (!$errors) {
        $chk = $conn->prepare('SELECT customer_id FROM customer WHERE account=?');
        $chk->bind_param('s', $account);
        $chk->execute();
        if ($chk->get_result()->num_rows > 0) $errors[] = '该账号已被注册，请更换';
    }

    if (!$errors) {
        $hash = hash_password($password);
        $conn->begin_transaction();
        try {
            // 写入客户表（下单需要）
            $ins = $conn->prepare('INSERT INTO customer(customer_name, contact_info, shipping_address, account, password, admin_id) VALUES (?,?,?,?,?,NULL)');
            $ins->bind_param('sssss', $name, $contact, $address, $account, $hash);
            $ins->execute();
            // 写入注册信息表（角色 4 = 普通客户）；若注册表用户名重复则忽略，不阻断主流程
            try {
                $reg = $conn->prepare('INSERT INTO registration_details(username, password, contact_info, shipping_address, role_id) VALUES (?,?,?,?,4)');
                $reg->bind_param('ssss', $account, $hash, $contact, $address);
                $reg->execute();
            } catch (Throwable $ignore) { /* 注册信息表非关键，忽略重复等异常 */ }
            $conn->commit();
            set_flash('success', '注册成功，请登录');
            header('Location: login.php');
            exit;
        } catch (Throwable $ex) {
            $conn->rollback();
            $errors[] = '注册失败：' . $ex->getMessage();
        }
    }
}

$page_title = '用户注册';
include __DIR__ . '/includes/header.php';
?>
<div class="form-box">
    <h2>用户注册</h2>
    <?php foreach ($errors as $err): ?>
        <div class="flash flash-error"><?= e($err) ?></div>
    <?php endforeach; ?>
    <form method="post">
        <div class="form-row"><label>姓名</label><input type="text" name="customer_name" value="<?= e($_POST['customer_name'] ?? '') ?>"></div>
        <div class="form-row"><label>登录账号</label><input type="text" name="account" value="<?= e($_POST['account'] ?? '') ?>"></div>
        <div class="form-row"><label>密码</label><input type="password" name="password"></div>
        <div class="form-row"><label>确认密码</label><input type="password" name="confirm"></div>
        <div class="form-row"><label>联系方式（手机/邮箱）</label><input type="text" name="contact_info" value="<?= e($_POST['contact_info'] ?? '') ?>"></div>
        <div class="form-row"><label>收货地址</label><textarea name="shipping_address" rows="2"><?= e($_POST['shipping_address'] ?? '') ?></textarea></div>
        <button class="btn btn-block" type="submit">注册</button>
    </form>
    <p class="form-tip">已有账号？<a href="login.php">去登录</a></p>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
