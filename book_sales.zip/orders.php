<?php
require_once __DIR__ . '/includes/functions.php';
require_customer();

$customer_id = (int)$_SESSION['customer_id'];
$stmt = $conn->prepare('SELECT order_id, status, total_amount, created_at, payment_time
                        FROM customer_order WHERE customer_id=? ORDER BY created_at DESC, order_id DESC');
$stmt->bind_param('i', $customer_id);
$stmt->execute();
$orders = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

function status_badge($s) {
    $map = ['待支付'=>'badge-orange','已支付'=>'badge-blue','已发货'=>'badge-blue','已完成'=>'badge-green','已取消'=>'badge-gray'];
    return '<span class="badge ' . ($map[$s] ?? 'badge-gray') . '">' . e($s) . '</span>';
}

$page_title = '我的订单';
include __DIR__ . '/includes/header.php';
?>
<h1 class="page-title">我的订单</h1>
<?php if (!$orders): ?>
    <div class="flash flash-info">还没有订单，<a href="index.php">去逛逛</a></div>
<?php else: ?>
<table class="data">
    <thead><tr><th>订单号</th><th>状态</th><th>总额</th><th>下单时间</th><th>支付时间</th><th>操作</th></tr></thead>
    <tbody>
    <?php foreach ($orders as $o): ?>
        <tr>
            <td>#<?= (int)$o['order_id'] ?></td>
            <td><?= status_badge($o['status']) ?></td>
            <td>￥<?= number_format($o['total_amount'], 2) ?></td>
            <td><?= e($o['created_at']) ?></td>
            <td><?= e($o['payment_time'] ?? '—') ?></td>
            <td><a class="btn btn-sm" href="order_detail.php?id=<?= (int)$o['order_id'] ?>">查看详情</a></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
<?php endif; ?>
<?php include __DIR__ . '/includes/footer.php'; ?>
