<?php
require_once __DIR__ . '/includes/functions.php';

// 2.1 图书查看与搜索：支持按书名/作者/出版社模糊搜索
$kw = trim($_GET['kw'] ?? '');
$sql = 'SELECT b.book_id, b.book_name, b.author, b.publisher, b.retail_price,
               COALESCE(i.quantity,0) AS quantity, COALESCE(i.status,\'缺货\') AS status
        FROM book b LEFT JOIN inventory i ON b.book_id = i.book_id';
$params = [];
if ($kw !== '') {
    $sql .= ' WHERE b.book_name LIKE ? OR b.author LIKE ? OR b.publisher LIKE ?';
    $like = '%' . $kw . '%';
    $params = [$like, $like, $like];
}
$sql .= ' ORDER BY b.book_id';
$stmt = $conn->prepare($sql);
if ($params) $stmt->bind_param('sss', ...$params);
$stmt->execute();
$books = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

$page_title = '图书商城';
include __DIR__ . '/includes/header.php';
?>
<h1 class="page-title">图书商城</h1>
<form class="searchbar" method="get">
    <input type="text" name="kw" placeholder="搜索书名 / 作者 / 出版社" value="<?= e($kw) ?>">
    <button class="btn" type="submit">搜索</button>
    <?php if ($kw !== ''): ?><a class="btn btn-gray" href="index.php">清除</a><?php endif; ?>
</form>

<?php if (!$books): ?>
    <div class="flash flash-info">没有找到相关图书</div>
<?php else: ?>
<div class="grid">
    <?php foreach ($books as $b):
        $q = (int)$b['quantity'];
        $stockCls = $q <= 0 ? 'stock-out' : ($b['status'] === '预警' ? 'stock-warn' : 'stock-ok');
    ?>
    <div class="card book-card">
        <h3><?= e($b['book_name']) ?></h3>
        <div class="meta">作者：<?= e($b['author']) ?></div>
        <div class="meta">出版社：<?= e($b['publisher']) ?></div>
        <div class="price">￥<?= number_format($b['retail_price'], 2) ?></div>
        <div class="stock <?= $stockCls ?>">库存：<?= $q ?> 本（<?= e($b['status']) ?>）</div>
        <?php if (is_customer_logged_in()): ?>
            <?php if ($q > 0): ?>
            <form method="post" action="cart_action.php">
                <input type="hidden" name="action" value="add">
                <input type="hidden" name="book_id" value="<?= (int)$b['book_id'] ?>">
                <button class="btn btn-sm btn-success" type="submit">加入购物车</button>
            </form>
            <?php else: ?>
                <button class="btn btn-sm btn-gray" disabled>暂时缺货</button>
            <?php endif; ?>
        <?php else: ?>
            <a class="btn btn-sm" href="login.php">登录后购买</a>
        <?php endif; ?>
    </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>
<?php include __DIR__ . '/includes/footer.php'; ?>
