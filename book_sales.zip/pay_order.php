$order_id = $_POST['order_id'] ?? 0;
$customer_id = $_SESSION['customer_id'];

// 先查订单归属，不限制状态
$checkSql = "SELECT order_id,status FROM customer_order WHERE order_id=? AND customer_id=?";
$stmt = $conn->prepare($checkSql);
$stmt->bind_param("ii", $order_id, $customer_id);
$stmt->execute();
$res = $stmt->get_result();
$row = $res->fetch_assoc();

if (!$row) {
    echo "<script>alert('订单不存在或不是你的订单');location='orders.php'</script>";
    exit;
}
if ($row['status'] != '待支付') {
    echo "<script>alert('该订单已支付，无需重复操作');location='order_detail.php?oid=$order_id'</script>";
    exit;
}
