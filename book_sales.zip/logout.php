<?php
require_once __DIR__ . '/includes/functions.php';
unset($_SESSION['customer_id'], $_SESSION['customer_name']);
set_flash('info', '您已退出登录');
header('Location: index.php');
exit;
